<?php
require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/controllers/PickupRequestController.php';

if (!Auth::check()) { header('Location: ' . APP_URL . '/user-junkshop/login.php'); exit; }
if (Auth::userRole() !== 'seller') { header('Location: ' . APP_URL . '/user-junkshop/dashboard.php'); exit; }

$controller = new PickupRequestController();
$requestId = (int) ($_GET['id'] ?? 0);
$request = $controller->getSellerRequestDetails($requestId, Auth::userId());
if ($request === null) { http_response_code(404); $pageTitle = 'Booking Not Found'; $content = '<div class="alert alert-warning">This booking could not be found in your account.</div>'; require_once __DIR__ . '/../app/views/user_dashboard_shell.php'; exit; }
$pageTitle = 'Booking Details';
$currentPage = 'current-bookings';
$userDisplayName = Auth::userName();
$assignment = $controller->getSellerRequestAssignmentSummary($requestId, Auth::userId());
$statusOrder = ['Pending Request', 'Matched', 'Accepted', 'Scheduled', 'For Pickup', 'Completed'];
$cancellableStatuses = ['Matched', 'Accepted'];
$canCancel = in_array($request['current_status'], $cancellableStatuses, true);
$currentStatusIndex = array_search($request['current_status'], $statusOrder, true);
$currentStatusIndex = $currentStatusIndex === false ? 0 : $currentStatusIndex;
$confirmedPickupDate = (string) ($request['formatted_pickup_date'] ?? '');
$confirmedPickupTime = (string) ($request['formatted_pickup_time'] ?? '');
ob_start();
?>
<div class="row g-4">
    <div class="col-12"><a href="<?php echo APP_URL; ?>/user-junkshop/current-bookings.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i> Current bookings</a></div>
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm"><div class="card-body p-4 p-lg-5"><div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-4"><div><p class="eyebrow mb-1">Booking tracking</p><h2 class="fw-bold mb-1"><?php echo Validator::escape($request['booking_reference']); ?></h2><p class="text-muted mb-0">Submitted <?php echo Validator::escape(date('M d, Y g:i A', strtotime($request['created_at']))); ?></p></div><span id="booking-current-status" class="status-badge <?php echo str_contains((string)$request['current_status'], 'Cancelled') ? 'rejected' : 'pending'; ?>"><?php echo Validator::escape($request['current_status']); ?></span></div>
            <div class="alert alert-info" role="note"><i class="bi bi-info-circle me-2"></i>EcoPick is facilitating this request. Registered junkshops handle collection, weighing, assessment, and purchase in later steps.</div>
            <div id="cancellation-control" class="mb-4"><?php if ($canCancel): ?><div class="d-flex justify-content-end"><button type="button" class="btn btn-sm btn-outline-danger" id="detail-cancel-request" onclick="openCancelBookingModal(<?php echo (int) $requestId; ?>)"><i class="bi bi-x-circle"></i> Cancel booking</button></div><?php endif; ?></div><div id="booking-cancellation-feedback" class="alert d-none mt-2" role="alert"></div>

            <div class="mb-4">
                <h5 class="fw-bold mb-3">Progress</h5>
                <div class="d-flex flex-wrap gap-2">
                    <?php foreach ($statusOrder as $index => $status): ?>
                        <?php $isComplete = $index <= $currentStatusIndex; $isActive = $index === $currentStatusIndex; ?>
                        <div class="flex-fill min-w-120px">
                            <div class="d-flex align-items-center gap-2 mb-2">
                                <span data-status-step="<?php echo Validator::escape($status); ?>" class="status-step rounded-circle d-inline-flex align-items-center justify-content-center <?php echo $isComplete ? 'bg-success text-white' : ($isActive ? 'bg-primary text-white' : 'bg-light text-muted'); ?>">
                                    <?php echo $isComplete ? '<i class="bi bi-check"></i>' : ($index + 1); ?>
                                </span>
                                <small data-status-label="<?php echo Validator::escape($status); ?>" class="fw-semibold <?php echo $isActive ? 'text-primary' : ($isComplete ? 'text-success' : 'text-muted'); ?>"><?php echo Validator::escape($status); ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <h5 class="fw-bold mb-3">Submitted materials</h5><div class="table-responsive mb-4"><table class="table align-middle"><thead class="table-light"><tr><th>Material</th><th>Category</th><th class="text-end">Estimated weight</th><?php if (!empty($assignment)): ?><th class="text-end">Matched price/kg</th><th class="text-end">Estimated value</th><?php endif; ?></tr></thead><tbody><?php $total_weight = 0; $total_price_per_kg = 0; $total_estimated_value = 0; foreach ($request['items'] as $item): $estimatedWeight = (float) $item['estimated_weight']; $matchedPrice = $item['matched_price_per_kg'] ?? null; $total_weight += $estimatedWeight; $total_price_per_kg += (float) $matchedPrice; $total_estimated_value += $estimatedWeight * (float) $matchedPrice; $estimatedValue = $item['actual_value'] ?? ($item['estimated_value'] ?? null); $isPendingMatch = $request['current_status'] === 'Pending Request' && $matchedPrice === null; ?><tr><td><?php echo Validator::escape($item['material_name']); ?></td><td><?php echo Validator::escape($item['category']); ?></td><td class="text-end"><?php echo number_format($estimatedWeight, 2); ?> <?php echo Validator::escape($item['unit_of_measure']); ?></td><?php if (!empty($assignment)): ?><td class="text-end"><?php echo $isPendingMatch ? '<span class="text-muted">Pending</span>' : '₱' . number_format((float) $matchedPrice, 2) . '/kg'; ?></td><td class="text-end"><?php echo $estimatedValue !== null ? '₱' . number_format((float) $estimatedValue, 2) : ($isPendingMatch ? '<span class="text-muted">Pending</span>' : '₱0.00'); ?></td><?php endif; ?></tr><?php endforeach; ?></tbody><tfoot><tr><th colspan="2">TOTAL</th><th class="text-end"><?php echo number_format($total_weight, 2); ?> kg</th><?php if (!empty($assignment)): ?><th class="text-end">₱<?php echo number_format($total_price_per_kg, 2); ?></th><th class="text-end">₱<?php echo number_format($total_estimated_value, 2); ?></th><?php endif; ?></tr></tfoot></table></div>
            <h5 class="fw-bold mb-3">Pickup information</h5><dl class="row mb-0"><dt class="col-sm-4 text-muted">Address</dt><dd class="col-sm-8"><?php echo Validator::escape($request['pickup_address']); ?></dd><dt class="col-sm-4 text-muted">Approximate distance</dt><dd class="col-sm-8"><?php echo number_format((float)($request['approximate_distance_km'] ?? 0), 2); ?> km</dd><dt class="col-sm-4 text-muted">Preferred date</dt><dd class="col-sm-8"><?php echo Validator::escape($request['preferred_pickup_date']); ?></dd><dt class="col-sm-4 text-muted">Preferred time</dt><dd class="col-sm-8"><?php echo Validator::escape($request['preferred_pickup_time']); ?></dd><dt class="col-sm-4 text-muted">Notes</dt><dd class="col-sm-8"><?php echo $request['notes'] !== null && $request['notes'] !== '' ? nl2br(Validator::escape($request['notes'])) : '<span class="text-muted">None provided</span>'; ?></dd><dt class="col-sm-4 text-muted">Photo</dt><dd class="col-sm-8"><?php echo $request['photo_path'] ? 'Photo uploaded with request' : '<span class="text-muted">None provided</span>'; ?></dd></dl>
            <?php if (($request['current_status'] ?? '') === 'For Pickup'): ?>
                <section id="seller-live-tracking" class="mt-4" data-status="For Pickup">
                    <div class="tracking-info"><p><strong class="text-danger">Your location:</strong> <span id="seller-location-label"><?php echo Validator::escape($request['pickup_address']); ?></span></p><p><strong class="text-danger">Junkshop collector location:</strong> <span id="junkshop-location-label">Fetching...</span></p><p><strong class="text-danger">Exact distance:</strong> <span id="seller-live-distance">Calculating...</span></p></div>
                </section>
            <?php endif; ?>
            <?php if (strtolower((string) ($request['current_status'] ?? '')) === 'completed'): ?><hr class="my-4"><section aria-labelledby="final-transaction-heading"><h5 id="final-transaction-heading" class="fw-bold mb-3">Final transaction calculation</h5><div class="d-flex justify-content-between gap-3"><span>Total Recyclable Value:</span><span>₱<?php echo number_format((float) $request['final_recyclable_value'], 2); ?></span></div><div class="d-flex justify-content-between gap-3"><span>Pickup / Collection fee:</span><span class="text-danger">- ₱<?php echo number_format((float) $request['final_pickup_fee'], 2); ?></span></div><div class="d-flex justify-content-between gap-3"><span>Ecopick service fee:</span><span class="text-danger">- ₱<?php echo number_format((float) $request['final_service_fee'], 2); ?></span></div><hr class="my-2"><div class="d-flex justify-content-between gap-3"><strong>Final net amount received:</strong><strong>₱<?php echo number_format((float) $request['final_net_amount'], 2); ?></strong></div></section><?php endif; ?>
        </div></div>
    </div>
    <div class="col-lg-4"><div class="card border-0 shadow-sm"><div class="card-body p-4">
        <?php if (strtolower((string) ($request['current_status'] ?? '')) === 'completed'): ?><section class="mb-4"><h5 class="fw-bold mb-3">Completed material conditions</h5><?php foreach ($request['items'] as $item): ?><div class="small mb-1"><?php echo Validator::escape($item['material_name']); ?><br>Condition: <?php echo !empty($item['material_condition']) ? htmlspecialchars($item['material_condition'], ENT_QUOTES, 'UTF-8') : 'N/A'; ?></div><?php endforeach; ?></section><?php endif; ?>
        <h5 class="fw-bold mb-4">Matched junkshop</h5>
        <?php if (!empty($assignment)): ?>
            <div class="bg-light rounded-3 p-3 mb-3">
                <div class="fw-semibold"><?php echo Validator::escape($assignment['business_name'] ?: 'Registered junkshop'); ?></div>
                <div class="small text-muted mt-1"><?php echo Validator::escape($assignment['junkshop_contact_name'] ?: 'Contact person'); ?></div>
                <div class="small text-muted mt-2"><?php echo Validator::escape($assignment['complete_address'] ?: 'Address pending'); ?></div>
            </div>
        <?php else: ?>
            <div class="alert alert-secondary mb-0">No matched junkshop is assigned for this request yet.</div>
        <?php endif; ?>

        <h5 class="fw-bold mb-4">Status timeline</h5><ol class="status-timeline list-unstyled mb-0"><?php foreach ($request['status_history'] as $history): ?><li class="status-timeline-item"><span class="status-timeline-dot"></span><div><strong><?php echo Validator::escape($history['new_status'] ?? ''); ?></strong><div class="small text-muted"><?php echo Validator::escape(date('M d, Y g:i A', strtotime($history['changed_at'] ?? 'now'))); ?> · <?php echo Validator::escape($history['responsible_party'] ?? 'System'); ?></div><?php if (($history['new_status'] ?? '') === 'Scheduled' && $confirmedPickupDate !== '' && $confirmedPickupTime !== ''): ?><div class="text-muted small mt-1">Scheduled for: <?php echo Validator::escape($confirmedPickupDate); ?> at <?php echo Validator::escape($confirmedPickupTime); ?></div><?php endif; ?></div></li><?php endforeach; ?></ol>
    </div></div></div>
</div>
<div class="modal fade" id="cancelBookingConfirmModal" tabindex="-1" aria-labelledby="cancelBookingConfirmModalLabel" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="cancelBookingConfirmModalLabel">Confirm Cancellation</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><p class="mb-0">Are you sure you want to cancel this pickup booking? This action cannot be undone.</p></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keep Booking</button><button type="button" class="btn btn-danger" id="btn-confirm-cancel">Yes, Cancel Booking</button></div></div></div></div>
<script>
window.addEventListener('DOMContentLoaded', function () {
    let activeBookingInterval = null;
    let currentActiveBookingId = null;
    let pollingInProgress = false;
    const requestId = <?php echo (int) $requestId; ?>;
    const detailsUrl = '<?php echo APP_URL; ?>/user-junkshop/api/pickup-requests.php?action=details&request_id=' + requestId;
    const statusOrder = <?php echo json_encode($statusOrder, JSON_UNESCAPED_UNICODE); ?>;
    const sellerLat = parseFloat(<?php echo json_encode($request['seller_lat']); ?>);
    const sellerLng = parseFloat(<?php echo json_encode($request['seller_lng']); ?>);
    const liveLocationUrl = '<?php echo APP_URL; ?>/user-junkshop/api/get_junkshop_live_location.php?booking_id=' + encodeURIComponent(requestId);
    let liveLocationTimeout = null;
    let lastGeocodedJunkshopLocation = null;

    function calculateDistance(lat1, lon1, lat2, lon2) {
        const earthRadiusKm = 6371;
        const latitudeDelta = (lat2 - lat1) * Math.PI / 180;
        const longitudeDelta = (lon2 - lon1) * Math.PI / 180;
        const a = Math.sin(latitudeDelta / 2) ** 2
            + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(longitudeDelta / 2) ** 2;
        return Number((earthRadiusKm * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))).toFixed(2));
    }

    function formatFullAddress(addressObj) {
        const address = addressObj || {};
        return [
            address.village || address.suburb || address.neighbourhood || address.quarter || '',
            address.city || address.town || address.municipality || '',
            address.state || address.province || address.region || ''
        ].filter(Boolean).join(', ');
    }

    function reverseGeocodeJunkshopLocation(lat, lng) {
        if (lastGeocodedJunkshopLocation && calculateDistance(lastGeocodedJunkshopLocation.lat, lastGeocodedJunkshopLocation.lng, lat, lng) < 0.05) return;
        lastGeocodedJunkshopLocation = { lat: lat, lng: lng };
        const url = 'https://nominatim.openstreetmap.org/reverse?format=json&lat=' + encodeURIComponent(lat) + '&lon=' + encodeURIComponent(lng);
        fetch(url, { headers: { Accept: 'application/json' } })
            .then(response => response.ok ? response.json() : null)
            .then(data => {
                const label = document.getElementById('junkshop-location-label');
                const address = formatFullAddress(data?.address);
                if (label && address) label.textContent = address;
            })
            .catch(function () {});
    }

    function stopLiveLocationPolling() {
        if (liveLocationTimeout !== null) {
            clearTimeout(liveLocationTimeout);
            liveLocationTimeout = null;
        }
    }

    function showWeakSignalAlert(message) {
        const container = document.getElementById('seller-live-tracking');
        if (!container) return;
        const warning = container.querySelector('.live-tracking-warning') || document.createElement('div');
        warning.className = 'live-tracking-warning alert alert-warning mt-3 mb-0';
        warning.setAttribute('role', 'alert');
        warning.textContent = message || 'Weak GPS signal or connection drop detected. Please check location settings or refresh/reload the website.';
        if (!warning.parentNode) {
            container.appendChild(warning);
        }
    }

    function clearWeakSignalAlert() {
        const container = document.getElementById('seller-live-tracking');
        if (!container) return;
        const warning = container.querySelector('.live-tracking-warning');
        if (warning) warning.remove();
    }

    function updateSellerLiveText(payload) {
        const container = document.getElementById('seller-live-tracking');
        if (!container || payload.status === 'Completed') {
            stopLiveLocationPolling();
            if (container) container.remove();
            return;
        }
        const collectorLat = Number.parseFloat(payload.collector_lat ?? payload.junkshop_lat);
        const collectorLng = Number.parseFloat(payload.collector_lng ?? payload.junkshop_lng);
        if (!Number.isFinite(sellerLat) || sellerLat < -90 || sellerLat > 90 || !Number.isFinite(sellerLng) || sellerLng < -180 || sellerLng > 180 || !Number.isFinite(collectorLat) || collectorLat < -90 || collectorLat > 90 || !Number.isFinite(collectorLng) || collectorLng < -180 || collectorLng > 180) return;
        clearWeakSignalAlert();
        reverseGeocodeJunkshopLocation(collectorLat, collectorLng);
        document.getElementById('seller-live-distance').textContent = calculateDistance(sellerLat, sellerLng, collectorLat, collectorLng).toFixed(2) + ' km';
    }

    function pollJunkshopLiveLocation() {
        if (document.hidden) {
            liveLocationTimeout = window.setTimeout(pollJunkshopLiveLocation, 10000);
            return;
        }
        fetch(liveLocationUrl, { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(response => {
                if (!response.ok) throw new Error('Live location request failed.');
                return response.json();
            })
            .then(payload => {
                if (!payload?.success) {
                    throw new Error(payload?.message || 'Unable to fetch live location.');
                }
                updateSellerLiveText(payload);
            })
            .catch(function () {
                showWeakSignalAlert('Weak GPS signal or connection drop detected. Please check location settings or refresh/reload the website.');
            })
            .finally(function () {
                if (document.getElementById('seller-live-tracking')) {
                    liveLocationTimeout = window.setTimeout(pollJunkshopLiveLocation, 10000);
                }
            });
    }

    if (document.getElementById('seller-live-tracking')) {
        pollJunkshopLiveLocation();
    }

    const formatTime = (value) => {
        const date = new Date('1970-01-01T' + String(value || '').trim().slice(0, 8));
        return Number.isNaN(date.getTime()) ? value : date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
    };

    const formatDateTime = (value) => {
        const date = new Date(String(value || '').replace(' ', 'T'));
        return Number.isNaN(date.getTime()) ? String(value || '') : date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' ' + date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
    };

    function updateProgress(currentStatus) {
        const currentIndex = statusOrder.indexOf(currentStatus);
        document.querySelectorAll('[data-status-step]').forEach((step) => {
            const stepIndex = statusOrder.indexOf(step.dataset.statusStep);
            const complete = currentIndex >= 0 && stepIndex <= currentIndex;
            const active = stepIndex === currentIndex;
            step.classList.remove('bg-success', 'bg-primary', 'bg-light', 'text-white', 'text-muted');
            step.classList.add(complete ? 'bg-success' : active ? 'bg-primary' : 'bg-light', complete || active ? 'text-white' : 'text-muted');
            step.innerHTML = complete ? '<i class="bi bi-check"></i>' : String(stepIndex + 1);
        });
        document.querySelectorAll('[data-status-label]').forEach((label) => {
            const labelIndex = statusOrder.indexOf(label.dataset.statusLabel);
            const active = labelIndex === currentIndex;
            const complete = currentIndex >= 0 && labelIndex <= currentIndex;
            label.classList.remove('text-primary', 'text-success', 'text-muted');
            label.classList.add(active ? 'text-primary' : complete ? 'text-success' : 'text-muted');
        });
    }

    function updateCancellationControl(currentStatus) {
        const control = document.getElementById('cancellation-control');
        if (!control) return;
        if (['Matched', 'Accepted'].includes(currentStatus)) {
            if (!document.getElementById('detail-cancel-request')) {
                control.innerHTML = '<div class="d-flex justify-content-end"><button type="button" class="btn btn-sm btn-outline-danger" id="detail-cancel-request" onclick="openCancelBookingModal(' + requestId + ')"><i class="bi bi-x-circle"></i> Cancel booking</button></div>';
            }
            return;
        }
        control.innerHTML = '';
    }

    const cancelModal = bootstrap.Modal.getOrCreateInstance(document.getElementById('cancelBookingConfirmModal'));
    let pendingCancellationId = null;
    window.openCancelBookingModal = function (bookingId) {
        pendingCancellationId = Number(bookingId);
        cancelModal.show();
    };
    async function cancelBooking(bookingId) {
        const data = new FormData();
        data.append('_csrf_token', '<?php echo CSRF::token(); ?>');
        data.append('booking_id', String(bookingId));
        try {
            const response = await fetch('<?php echo APP_URL; ?>/user-junkshop/cancel_booking.php', { method: 'POST', body: data, credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
            const payload = await response.json();
            if (!response.ok || payload.success !== true) throw new Error(payload.message || 'The booking could not be cancelled.');
            const status = document.getElementById('booking-current-status');
            if (status) {
                status.textContent = 'Cancelled';
                status.classList.add('rejected');
                status.classList.remove('pending');
            }
            updateCancellationControl('Cancelled');
            const openModal = document.querySelector('.modal.show');
            if (openModal && window.bootstrap?.Modal) window.bootstrap.Modal.getInstance(openModal)?.hide();
            const feedback = document.getElementById('booking-cancellation-feedback');
            feedback.textContent = payload.message || 'Booking cancelled successfully.';
            feedback.className = 'alert alert-success mt-2';
            cancelModal.hide();
        } catch (error) {
            const feedback = document.getElementById('booking-cancellation-feedback');
            feedback.textContent = error.message || 'Unable to cancel the booking right now.';
            feedback.className = 'alert alert-danger mt-2';
        }
    };
    document.getElementById('btn-confirm-cancel').addEventListener('click', function () {
        if (pendingCancellationId) cancelBooking(pendingCancellationId);
    });

    function updateTimeline(history, request) {
        const timeline = document.querySelector('.status-timeline');
        if (!timeline || !Array.isArray(history)) return;
        history.forEach((entry, index) => {
            let item = timeline.children[index];
            if (!item) {
                item = document.createElement('li');
                item.className = 'status-timeline-item';
                item.innerHTML = '<span class="status-timeline-dot"></span><div><strong></strong><div class="small text-muted"></div></div>';
                timeline.appendChild(item);
            }
            const status = String(entry.new_status || '');
            const text = item.querySelector('strong');
            const metadata = item.querySelector('.small.text-muted');
            if (text) text.textContent = status;
            if (metadata) metadata.textContent = formatDateTime(entry.changed_at) + ' · ' + String(entry.responsible_party || 'System');
            if (status === 'Scheduled') {
                let schedule = item.querySelector('#timeline-schedule-text, .mt-1');
                if (!schedule) {
                    schedule = document.createElement('div');
                    schedule.id = 'timeline-schedule-text';
                    schedule.className = 'text-muted small mt-1';
                    item.querySelector('div').appendChild(schedule);
                }
                const date = request.formatted_pickup_date || request.confirmed_pickup_date || '';
                const time = request.formatted_pickup_time || request.confirmed_pickup_time || '';
                schedule.textContent = date && time ? 'Scheduled for: ' + date + ' at ' + time : '';
            }
        });
    }

    function updateItemPrices(items) {
        if (!Array.isArray(items)) return;
        const rows = document.querySelectorAll('.table-responsive tbody tr');
        items.forEach((item, index) => {
            const row = rows[index];
            if (!row || row.cells.length < 5) return;
            const price = item.matched_price_per_kg;
            const value = item.actual_value ?? item.estimated_value;
            row.cells[3].textContent = price === null || price === undefined ? 'Pending' : '₱' + Number(price).toFixed(2) + '/kg';
            row.cells[4].textContent = value === null || value === undefined ? 'Pending' : '₱' + Number(value).toFixed(2);
        });
    }

    function applyBookingUpdate(request) {
        const status = document.getElementById('booking-current-status');
        if (status) {
            status.textContent = request.current_status || '';
            status.classList.toggle('rejected', request.current_status === 'Cancelled');
            status.classList.toggle('pending', request.current_status !== 'Cancelled');
        }
        updateProgress(request.current_status);
        updateCancellationControl(request.current_status);
        updateTimeline(request.status_history, request);
        updateItemPrices(request.items);
        if (request.current_status === 'Completed') stopLiveLocationPolling();
    }

    function stopBookingPolling() {
        if (activeBookingInterval !== null) {
            clearInterval(activeBookingInterval);
            activeBookingInterval = null;
        }
        currentActiveBookingId = null;
    }

    async function pollActiveBooking() {
        if (!currentActiveBookingId || pollingInProgress || document.hidden) return;
        pollingInProgress = true;
        try {
            const response = await fetch(detailsUrl, { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
            const payload = await response.json();
            if (payload.session_expired && payload.redirect) {
                window.location.href = payload.redirect;
                return;
            }
            if (response.ok && payload.success && payload.data?.request) applyBookingUpdate(payload.data.request);
        } catch (error) {
            console.error('Failed to refresh booking details:', error);
        } finally {
            pollingInProgress = false;
        }
    }

    function startBookingPolling(bookingId) {
        stopBookingPolling();
        currentActiveBookingId = Number(bookingId);
        pollActiveBooking();
        activeBookingInterval = setInterval(pollActiveBooking, 10000);
    }

    document.querySelectorAll('dt').forEach((label) => {
        const value = label.nextElementSibling;
        if (label.textContent.trim() === 'Preferred time' && value) value.textContent = formatTime(value.textContent);
    });

    document.getElementById('bookingDetailsModal')?.addEventListener('hidden.bs.modal', stopBookingPolling);
    window.addEventListener('pagehide', stopBookingPolling, { once: true });
    startBookingPolling(requestId);

});
</script>
<?php
$content = ob_get_clean();
require_once __DIR__ . '/../app/views/user_dashboard_shell.php';
